import Vue from 'vue';
import VueRouter from 'vue-router';
import HomeView from '../views/HomeView.vue';
import AboutView from '../views/AboutView.vue';
import AlertasView from '../views/AlertasView.vue';
import HistorialView from '../views/HistorialView.vue';
import LoginView from "../views/LoginView.vue";
import RegisterView from "../views/RegisterView.vue";

Vue.use(VueRouter);

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/about',
    name: 'about',
    component: AboutView
  },
  {
    path: '/alertas',
    name: 'alertas',
    component: AlertasView
  },
  {
    path: '/historial',
    name: 'historial',
    component: HistorialView
  },
  { path: "/login", 
    name: 'login',
    component: LoginView 
  },
  { path: "/register",
    name: 'register', 
    component: RegisterView 
  }
];

const router = new VueRouter({
  mode: 'history', // Para usar rutas amigables sin hash
  routes
});

export default router;

