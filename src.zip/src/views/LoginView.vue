<template>
  <div class="login">
    <h1 class="title">Iniciar sesión</h1>
    <form class="form" @submit.prevent="login">
      <label class="form-label" for="email">Email:</label>
      <input v-model="email" class="form-input" type="email" id="email" required placeholder="Email" />
      <label class="form-label" for="password">Contraseña:</label>
      <input v-model="password" class="form-input" type="password" id="password" required placeholder="Contraseña" />
      <p v-if="errorMessage" class="error-message">{{ errorMessage }}</p>
      <input class="form-submit" type="submit" value="Iniciar sesión" />
    </form>

    <!-- Mensaje de éxito de login -->
    <div v-if="loginSuccess" class="login-success-message">
      <h2>¡Bienvenido! Has iniciado sesión correctamente.</h2>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      email: "",
      password: "",
      errorMessage: "", // Variable para almacenar el mensaje de error
      loginSuccess: false,  // Variable para manejar el mensaje de éxito
    };
  },
  methods: {
    async login() {
      try {
        const response = await fetch("http://localhost:3000/login", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            email: this.email,
            password: this.password,
          }),
          credentials: 'include', // Incluye las cookies
        });

        const data = await response.json();

        if (response.ok) {
          this.errorMessage = ""; // Limpiar el mensaje de error
          this.loginSuccess = true;  // Mostrar el mensaje de éxito
          setTimeout(() => {
            this.loginSuccess = false; // Ocultar el mensaje después de 3 segundos
          }, 3000);
          this.$router.push('/'); // Redirigir a la página de inicio
        } else {
          this.errorMessage = data.message || "Error desconocido"; // Establecer el mensaje de error
        }
      } catch (error) {
        this.errorMessage = "Error al conectar con el servidor."; // Error de red
        console.error("Error de red:", error);
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.login {
  padding: 2rem;
}
.title {
  text-align: center;
}
.form {
  margin: 3rem auto;
  display: flex;
  flex-direction: column;
  justify-content: center;
  width: 20%;
  min-width: 350px;
  max-width: 100%;
  background: rgba(19, 35, 47, 0.9);
  border-radius: 5px;
  padding: 40px;
  box-shadow: 0 4px 10px 4px rgba(0, 0, 0, 0.3);
}
.form-label {
  margin-top: 2rem;
  color: white;
  margin-bottom: 0.5rem;
  &:first-of-type {
    margin-top: 0rem;
  }
}
.form-input {
  padding: 10px 15px;
  background: none;
  background-image: none;
  border: 1px solid white;
  color: white;
  &:focus {
    outline: 0;
    border-color: #1ab188;
  }
}
.form-submit {
  background: #1ab188;
  border: none;
  color: white;
  margin-top: 3rem;
  padding: 1rem 0;
  cursor: pointer;
  transition: background 0.2s;
  &:hover {
    background: #0b9185;
  }
}
.error-message {
  color: red;
  font-size: 0.9rem;
  margin-top: 1rem;
  text-align: center;
}

/* Estilo para el mensaje de éxito */
.login-success-message {
  background-color: #42b983;
  color: white;
  padding: 20px;
  border-radius: 5px;
  margin-top: 20px;
  font-size: 1.5rem;
  text-align: center;
  animation: fadeIn 1s ease-out;
}

/* Animación para el mensaje */
@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
</style>
