<template>
  <div id="app">
    <nav class="navbar">
      <div class="navbar-links">
        <router-link to="/">Home</router-link> |
        <router-link to="/alertas">Alertas de Seguridad</router-link> |
        <router-link to="/historial">Historial de Conexiones</router-link> |
        <router-link to="/about">About</router-link>
      </div>
      <div class="navbar-buttons">
        <button v-if="!isLoggedIn" @click="signIn">Sign In</button>
        <button v-if="!isLoggedIn" @click="signUp">Sign Up</button>
        <button v-if="isLoggedIn" @click="logout">Cerrar sesión</button>
        <div v-if="isLoggedIn">
          <p>¡Bienvenido!</p>
        </div>
      </div>
    </nav>

    <router-view/>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isLoggedIn: false,
    };
  },
  created() {
    // Verificar la sesión al cargar el componente
    this.verifySession();
  },
  methods: {
    // Método para verificar si el usuario está autenticado
    verifySession() {
      fetch('http://localhost:3000/verify-session', {
        method: 'GET',
        credentials: 'include',  // Asegúrate de enviar cookies con la solicitud
      })
      .then(response => {
        if (response.ok) {
          this.isLoggedIn = true;  // El usuario está autenticado
        } else {
          this.isLoggedIn = false; // El usuario no está autenticado
        }
      })
      .catch(error => {
        console.error('Error al verificar la sesión:', error);
        this.isLoggedIn = false;  // Si hay un error, asumimos que el usuario no está autenticado
      });
    },

    signIn() {
      this.$router.push('/login');
    },
    signUp() {
      this.$router.push('/register');
    },

    // Método para cerrar sesión
    logout() {
      // Eliminar la cookie de sesión
      document.cookie = "SessionID=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
      
      // Actualizar el estado
      this.isLoggedIn = false;
      this.$router.push('/');  // Redirigir al home después de cerrar sesión
    }
  },
};
</script>

<style scoped>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

.navbar {
  display: flex;
  justify-content: space-between;
  padding: 30px;
  align-items: center;
}

.navbar-links {
  display: flex;
  gap: 10px;
}

.navbar-buttons {
  display: flex;
  gap: 10px;
}

button {
  font-weight: bold;
  color: white;
  background-color: #42b983;
  border: none;
  padding: 10px 15px;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s;
}

button:hover {
  background-color: #2c3e50;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
  text-decoration: none;
}

nav a.router-link-exact-active {
  color: #42b983;
}
</style>
